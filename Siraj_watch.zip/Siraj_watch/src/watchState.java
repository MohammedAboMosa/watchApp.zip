
public interface watchState {

	public void alert();

	public void buttonB();

	public void buttonC();
}
